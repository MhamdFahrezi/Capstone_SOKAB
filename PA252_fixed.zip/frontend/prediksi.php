<?php include 'header.php'; 
$hasil = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        "MASA_PEROLEHAN" => floatval($_POST['MASA_PEROLEHAN']),
        "NILAI_PEROLEHAN" => floatval($_POST['NILAI_PEROLEHAN']),
        "Aset_Baru" => intval($_POST['Aset_Baru']),
        "Perolehan_Mahal" => intval($_POST['Perolehan_Mahal']),
        "Akum_Jan_Tinggi" => intval($_POST['Akum_Jan_Tinggi']),
        "Akum_Des_Tinggi" => intval($_POST['Akum_Des_Tinggi']),
        "S1_DiAtasRata" => intval($_POST['S1_DiAtasRata']),
        "S2_DiAtasRata" => intval($_POST['S2_DiAtasRata']),
        "Selisih_Semester" => floatval($_POST['Selisih_Semester']),
        "Umur_Aset" => floatval($_POST['Umur_Aset'])
    ];

    $ch = curl_init('https://fastapi-production-d8cb.up.railway.app/predict');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    curl_close($ch);

    $hasil = json_decode($response, true);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Prediksi Penyusutan Aset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="header animate-fadein">
        <h2>Form Prediksi Penyusutan Aset</h2>
        <p>Sistem Prediksi Penyusutan Puskesmas</p>
    </div>
    <div class="container mt-4">
        <div class="form-section">
            <form id="prediksiForm" class="row g-3" method="POST" action="">
                <?php
                $fields = [
                    "MASA_PEROLEHAN" => "Masa Perolehan",
                    "NILAI_PEROLEHAN" => "Nilai Perolehan",
                    "Aset_Baru" => "Aset Baru (0/1)",
                    "Perolehan_Mahal" => "Perolehan Mahal (0/1)",
                    "Akum_Jan_Tinggi" => "Akumulasi Jan Tinggi (0/1)",
                    "Akum_Des_Tinggi" => "Akumulasi Des Tinggi (0/1)",
                    "S1_DiAtasRata" => "Semester 1 Di Atas Rata-rata (0/1)",
                    "S2_DiAtasRata" => "Semester 2 Di Atas Rata-rata (0/1)",
                    "Selisih_Semester" => "Selisih Semester",
                    "Umur_Aset" => "Umur Aset"
                ];
                foreach ($fields as $name => $label):
                ?>
                    <div class="col-md-6">
                        <label class="form-label"><?= $label ?>:</label>
                        <input type="number" step="any" name="<?= $name ?>" class="form-control" required>
                    </div>
                <?php endforeach; ?>
                <div class="col-12">
    <?php if ($hasil): ?>
        <div class="alert alert-success mt-4">
            <h4>Hasil Prediksi:</h4>
            <p><strong>Penyusutan Semester 1:</strong> <?= htmlspecialchars($hasil['Prediksi_Penyusutan_Semester_1']) ?></p>
            <p><strong>Penyusutan Semester 2:</strong> <?= htmlspecialchars($hasil['Prediksi_Penyusutan_Semester_2']) ?></p>
        </div>
    <?php else: ?>
        <button type="submit" class="btn btn-hijau w-100">Prediksi</button>
    <?php endif; ?>
</div>


</body>
<?php include 'footer.php'; ?>
</html>
