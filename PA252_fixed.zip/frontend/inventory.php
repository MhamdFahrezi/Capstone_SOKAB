<?php
session_start();
require_once 'header.php';
require_once '../backend/database.php';

// Cek izin pengguna
if ($_SESSION['role'] === 'admin') {
    $can_create = $can_read = $can_update = $can_delete = true;
} else {
    $stmt = $pdo->prepare("SELECT can_create, can_read, can_update, can_delete FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $permissions = $stmt->fetch();
    
    $can_create = $permissions['can_create'] ?? false;
    $can_read = $permissions['can_read'] ?? false;
    $can_update = $permissions['can_update'] ?? false;
    $can_delete = $permissions['can_delete'] ?? false;
}

// Proses CRUD
$action = $_GET['action'] ?? '';

if ($action == 'create' && $can_create) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            $_POST['nama_aset'],
            $_POST['masa_perolehan'],
            $_POST['nilai_perolehan'],
            $_POST['sisa_manfaat_tahun'],
            $_POST['sisa_manfaat_bulan'],
            $_POST['akumulasi_penyusutan_awal'],
            $_POST['penyusutan_semester1'],
            $_POST['penyusutan_semester2'],
            $_POST['akumulasi_penyusutan_akhir'],
            $_POST['nilai_buku'],
            $_POST['usia_aset'],
            $_POST['terhitung'],
            $_POST['hasil_akhir_penyusutan'],
            $_POST['ada_penyusutan_s1'],
            $_POST['ada_penyusutan_s2'],
            $_POST['usia_aset_mapped'],
            $_POST['semester_depreciation_change_mapped']
        ];

        $stmt = $pdo->prepare("INSERT INTO inventaris (
            nama_aset, masa_perolehan, nilai_perolehan, sisa_manfaat_tahun, 
            sisa_manfaat_bulan, akumulasi_penyusutan_awal, penyusutan_semester1, 
            penyusutan_semester2, akumulasi_penyusutan_akhir, nilai_buku, 
            usia_aset, terhitung, hasil_akhir_penyusutan, ada_penyusutan_s1, 
            ada_penyusutan_s2, usia_aset_mapped, semester_depreciation_change_mapped
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute($data);
        $_SESSION['flash_message'] = 'Data berhasil ditambahkan';
        header("Location: inventory.php");
        exit();
    }
} elseif ($action == 'update' && $can_update) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            $_POST['nama_aset'],
            $_POST['masa_perolehan'],
            $_POST['nilai_perolehan'],
            $_POST['sisa_manfaat_tahun'],
            $_POST['sisa_manfaat_bulan'],
            $_POST['akumulasi_penyusutan_awal'],
            $_POST['penyusutan_semester1'],
            $_POST['penyusutan_semester2'],
            $_POST['akumulasi_penyusutan_akhir'],
            $_POST['nilai_buku'],
            $_POST['usia_aset'],
            $_POST['terhitung'],
            $_POST['hasil_akhir_penyusutan'],
            $_POST['ada_penyusutan_s1'],
            $_POST['ada_penyusutan_s2'],
            $_POST['usia_aset_mapped'],
            $_POST['semester_depreciation_change_mapped'],
            $_POST['id']
        ];

        $stmt = $pdo->prepare("UPDATE inventaris SET 
            nama_aset = ?, masa_perolehan = ?, nilai_perolehan = ?, 
            sisa_manfaat_tahun = ?, sisa_manfaat_bulan = ?,
            akumulasi_penyusutan_awal = ?, penyusutan_semester1 = ?,
            penyusutan_semester2 = ?, akumulasi_penyusutan_akhir = ?,
            nilai_buku = ?, usia_aset = ?, terhitung = ?,
            hasil_akhir_penyusutan = ?, ada_penyusutan_s1 = ?,
            ada_penyusutan_s2 = ?, usia_aset_mapped = ?,
            semester_depreciation_change_mapped = ? WHERE id = ?");
            
        $stmt->execute($data);
        $_SESSION['flash_message'] = 'Data berhasil diperbarui';
        header("Location: inventory.php");
        exit();
    } else {
        $id = $_GET['id'];
        $stmt = $pdo->prepare("SELECT * FROM inventaris WHERE id = ?");
        $stmt->execute([$id]);
        $item = $stmt->fetch();
    }
} elseif ($action == 'delete' && $can_delete) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $pdo->prepare("DELETE FROM inventaris WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['flash_message'] = 'Data berhasil dihapus';
        header("Location: inventory.php");
        exit();
    }
}
?>

<div class="container mt-4">
    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= $_SESSION['flash_message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h4 class="m-0 font-weight-bold text-primary">Daftar Inventaris</h4>
            <?php if ($can_create): ?>
                <a href="inventory.php?action=create" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah Barang
                </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="color: black;">NAMA ASET</th>
                            <th style="color: black;">MASA PEROLEHAN</th>
                            <th style="color: black;">NILAI PEROLEHAN</th>
                            <th style="color: black;">SISA MANFAAT TAHUN</th>
                            <th style="color: black;">SISA MANFAAT BULAN</th>
                            <th style="color: black;">AKUMULASI PENYUSUTAN 1 JANUARI 2024</th>
                            <th style="color: black;">PENYUSUTAN SEMESTER 1</th>
                            <th style="color: black;">PENYUSUTAN SEMESTER 2</th>
                            <th style="color: black;">AKUMULASI PENYUSUTAN 31 DESEMBER 2024</th>
                            <th style="color: black;">NILAI BUKU</th>
                            <th style="color: black;">USIA ASET</th>
                            <th style="color: black;">TERHITUNG</th>
                            <th style="color: black;">HASIL AKHIR PENYUSUTAN</th>
                            <th style="color: black;">ADA_PENYUSUTAN_S1</th>
                            <th style="color: black;">ADA_PENYUSUTAN_S2</th>
                            <th style="color: black;">USIA ASET_MAPPED</th>
                            <th style="color: black;">SEMESTER_DEPRECIATION_CHANGE_MAPPED</th>
                            <?php if ($can_update || $can_delete): ?>
                                <th>AKSI</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM inventaris");
                        while ($row = $stmt->fetch()):
                        ?>
                            <tr>
                                <td><?= htmlspecialchars($row['nama_aset']) ?></td>
                                <td><?= $row['masa_perolehan'] ?></td>
                                <td><?= number_format($row['nilai_perolehan'], 0, ',', '.') ?></td>
                                <td><?= $row['sisa_manfaat_tahun'] ?></td>
                                <td><?= $row['sisa_manfaat_bulan'] ?></td>
                                <td><?= number_format($row['akumulasi_penyusutan_awal'], 0, ',', '.') ?></td>
                                <td><?= number_format($row['penyusutan_semester1'], 0, ',', '.') ?></td>
                                <td><?= number_format($row['penyusutan_semester2'], 0, ',', '.') ?></td>
                                <td><?= number_format($row['akumulasi_penyusutan_akhir'], 0, ',', '.') ?></td>
                                <td><?= number_format($row['nilai_buku'], 0, ',', '.') ?></td>
                                <td><?= htmlspecialchars($row['usia_aset']) ?></td>
                                <td><?= htmlspecialchars($row['terhitung']) ?></td>
                                <td><?= htmlspecialchars($row['hasil_akhir_penyusutan']) ?></td>
                                <td><?= $row['ada_penyusutan_s1'] ? 'Ya' : 'Tidak' ?></td>
                                <td><?= $row['ada_penyusutan_s2'] ? 'Ya' : 'Tidak' ?></td>
                                <td><?= $row['usia_aset_mapped'] ?></td>
                                <td><?= $row['semester_depreciation_change_mapped'] ?></td>
                                <?php if ($can_update || $can_delete): ?>
                                    <td>
                                        <?php if ($can_update): ?>
                                            <a href="inventory.php?action=update&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($can_delete): ?>
                                            <a href="inventory.php?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                                <i class="fas fa-trash"></i> Hapus
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Form untuk Create/Update -->
    <?php if (($action == 'create' && $can_create) || ($action == 'update' && $can_update)): ?>
    <div class="card shadow mt-4">
        <div class="card-header py-3">
            <h5 class="m-0 font-weight-bold text-primary">
                <?= ($action == 'update') ? 'Edit' : 'Tambah' ?> Inventaris
            </h5>
        </div>
        <div class="card-body">
            <form method="POST" action="inventory.php?action=<?= $action ?>">
                <?php if ($action == 'update'): ?>
                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nama_aset">NAMA ASET</label>
                            <input type="text" class="form-control" id="nama_aset" name="nama_aset" 
                                   value="<?= isset($item) ? htmlspecialchars($item['nama_aset']) : '' ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="masa_perolehan">MASA PEROLEHAN</label>
                            <input type="number" class="form-control" id="masa_perolehan" name="masa_perolehan" 
                                   value="<?= isset($item) ? $item['masa_perolehan'] : '' ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="nilai_perolehan">NILAI PEROLEHAN</label>
                            <input type="number" class="form-control" id="nilai_perolehan" name="nilai_perolehan" 
                                   value="<?= isset($item) ? $item['nilai_perolehan'] : '' ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="sisa_manfaat_tahun">SISA MANFAAT TAHUN</label>
                            <input type="number" class="form-control" id="sisa_manfaat_tahun" name="sisa_manfaat_tahun" 
                                   value="<?= isset($item) ? $item['sisa_manfaat_tahun'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="sisa_manfaat_bulan">SISA MANFAAT BULAN</label>
                            <input type="number" class="form-control" id="sisa_manfaat_bulan" name="sisa_manfaat_bulan" 
                                   value="<?= isset($item) ? $item['sisa_manfaat_bulan'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="akumulasi_penyusutan_awal">AKUMULASI PENYUSUTAN 1 JANUARI 2024</label>
                            <input type="number" class="form-control" id="akumulasi_penyusutan_awal" name="akumulasi_penyusutan_awal" 
                                   value="<?= isset($item) ? $item['akumulasi_penyusutan_awal'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="penyusutan_semester1">PENYUSUTAN SEMESTER 1</label>
                            <input type="number" class="form-control" id="penyusutan_semester1" name="penyusutan_semester1" 
                                   value="<?= isset($item) ? $item['penyusutan_semester1'] : 0 ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="penyusutan_semester2">PENYUSUTAN SEMESTER 2</label>
                            <input type="number" class="form-control" id="penyusutan_semester2" name="penyusutan_semester2" 
                                   value="<?= isset($item) ? $item['penyusutan_semester2'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="akumulasi_penyusutan_akhir">AKUMULASI PENYUSUTAN 31 DESEMBER 2024</label>
                            <input type="number" class="form-control" id="akumulasi_penyusutan_akhir" name="akumulasi_penyusutan_akhir" 
                                   value="<?= isset($item) ? $item['akumulasi_penyusutan_akhir'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="nilai_buku">NILAI BUKU</label>
                            <input type="number" class="form-control" id="nilai_buku" name="nilai_buku" 
                                   value="<?= isset($item) ? $item['nilai_buku'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="usia_aset">USIA ASET</label>
                            <select class="form-control" id="usia_aset" name="usia_aset">
                                <option value="Baru" <?= (isset($item) && $item['usia_aset'] == 'Baru') ? 'selected' : '' ?>>Baru</option>
                                <option value="Sedang" <?= (isset($item) && $item['usia_aset'] == 'Sedang') ? 'selected' : '' ?>>Sedang</option>
                                <option value="Lama" <?= (isset($item) && $item['usia_aset'] == 'Lama') ? 'selected' : '' ?>>Lama</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="terhitung">TERHITUNG</label>
                            <select class="form-control" id="terhitung" name="terhitung">
                                <option value="Murah" <?= (isset($item) && $item['terhitung'] == 'Murah') ? 'selected' : '' ?>>Murah</option>
                                <option value="Sedang" <?= (isset($item) && $item['terhitung'] == 'Sedang') ? 'selected' : '' ?>>Sedang</option>
                                <option value="Mahal" <?= (isset($item) && $item['terhitung'] == 'Mahal') ? 'selected' : '' ?>>Mahal</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="hasil_akhir_penyusutan">HASIL AKHIR PENYUSUTAN</label>
                            <select class="form-control" id="hasil_akhir_penyusutan" name="hasil_akhir_penyusutan">
                                <option value="Naik" <?= (isset($item) && $item['hasil_akhir_penyusutan'] == 'Naik') ? 'selected' : '' ?>>Naik</option>
                                <option value="Stabil" <?= (isset($item) && $item['hasil_akhir_penyusutan'] == 'Stabil') ? 'selected' : '' ?>>Stabil</option>
                                <option value="Menurun" <?= (isset($item) && $item['hasil_akhir_penyusutan'] == 'Menurun') ? 'selected' : '' ?>>Menurun</option>
                            </select>
                        </div>
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="ada_penyusutan_s1" name="ada_penyusutan_s1" value="1" <?= (isset($item) && $item['ada_penyusutan_s1']) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="ada_penyusutan_s1">ADA_PENYUSUTAN_S1</label>
                        </div>
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="ada_penyusutan_s2" name="ada_penyusutan_s2" value="1" <?= (isset($item) && $item['ada_penyusutan_s2']) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="ada_penyusutan_s2">ADA_PENYUSUTAN_S2</label>
                        </div>
                        <div class="form-group">
                            <label for="usia_aset_mapped">USIA ASET_MAPPED</label>
                            <input type="number" class="form-control" id="usia_aset_mapped" name="usia_aset_mapped" 
                                   value="<?= isset($item) ? $item['usia_aset_mapped'] : 0 ?>">
                        </div>
                        <div class="form-group">
                            <label for="semester_depreciation_change_mapped">SEMESTER_DEPRECIATION_CHANGE_MAPPED</label>
                            <input type="number" class="form-control" id="semester_depreciation_change_mapped" name="semester_depreciation_change_mapped" 
                                   value="<?= isset($item) ? $item['semester_depreciation_change_mapped'] : 0 ?>">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan
                </button>
                <a href="inventory.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Batal
                </a>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include('footer.php'); ?>