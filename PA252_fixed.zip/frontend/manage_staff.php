<?php
session_start();
require_once '../backend/database.php';
require_once 'header.php';

// Verifikasi hanya admin yang bisa akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: unauthorized.php");
    exit;
}

// Proses update izin staff
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_permission'])) {
    $staff_id = $_POST['user_id'];
    
    // Ambil data izin dari form
    $permissions = [
        'can_create' => isset($_POST['can_create']) ? 1 : 0,
        'can_read' => isset($_POST['can_read']) ? 1 : 0,
        'can_update' => isset($_POST['can_update']) ? 1 : 0,
        'can_delete' => isset($_POST['can_delete']) ? 1 : 0
    ];

    try {
        // Pastikan hanya mengupdate staff (bukan admin)
        $sql = "UPDATE users SET 
                can_create = :create, 
                can_read = :read, 
                can_update = :update, 
                can_delete = :delete 
                WHERE id = :id AND role = 'staff'";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':create' => $permissions['can_create'],
            ':read' => $permissions['can_read'],
            ':update' => $permissions['can_update'],
            ':delete' => $permissions['can_delete'],
            ':id' => $staff_id
        ]);

        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => 'Hak akses staff berhasil diperbarui!'
        ];
    } catch (PDOException $e) {
        $_SESSION['flash_message'] = [
            'type' => 'danger',
            'message' => 'Gagal memperbarui hak akses: ' . $e->getMessage()
        ];
    }
    
    header("Location: manage_staff.php");
    exit;
}

// Ambil daftar semua staff
try {
    $stmt = $pdo->query("SELECT id, username, can_create, can_read, can_update, can_delete FROM users WHERE role = 'staff'");
    $staffList = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $staffList = [];
    $_SESSION['flash_message'] = [
        'type' => 'danger',
        'message' => 'Gagal memuat data staff: ' . $e->getMessage()
    ];
}
?>

<div class="container mt-4">
    <!-- Notifikasi -->
    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="alert alert-<?= $_SESSION['flash_message']['type'] ?> alert-dismissible fade show">
            <?= $_SESSION['flash_message']['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h4 class="m-0 font-weight-bold text-primary">Kelola Hak Akses Staff</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th>Username</th>
                            <th class="text-center">Create</th>
                            <th class="text-center">Read</th>
                            <th class="text-center">Update</th>
                            <th class="text-center">Delete</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($staffList)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data staff</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($staffList as $staff): ?>
                            <tr>
                                <form method="POST">
                                    <td><?= htmlspecialchars($staff['username']) ?></td>
                                    <td class="text-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="can_create" 
                                                <?= $staff['can_create'] ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="can_read" 
                                                <?= $staff['can_read'] ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="can_update" 
                                                <?= $staff['can_update'] ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="can_delete" 
                                                <?= $staff['can_delete'] ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                    <td>
                                        <input type="hidden" name="user_id" value="<?= $staff['id'] ?>">
                                        <button type="submit" name="update_permission" class="btn btn-sm btn-primary">
                                            <i class="fas fa-save"></i> Simpan
                                        </button>
                                    </td>
                                </form>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>