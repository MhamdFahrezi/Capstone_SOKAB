<!-- footer.php -->
    <footer class="bg-light text-center py-3">
        <p>&copy; 2025 Puskesmas. Semua hak dilindungi.</p>
    </footer>
    
    <!-- Tautkan Bootstrap JS dan custom JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="app.js"></script> <!-- Tautkan custom JS -->
</body>
</html>
