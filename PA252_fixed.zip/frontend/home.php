<?php include('header.php'); ?>

<div class="container">
    <h1>Selamat Datang di Website Puskesmas</h1>
    <p>Website ini digunakan untuk mengelola **inventory** barang dan melakukan prediksi penyusutan barang berdasarkan data yang diunggah.</p>
</div>

<?php include('footer.php'); ?>
