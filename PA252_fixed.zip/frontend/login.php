<?php
session_start();
include('../backend/database.php');

// Cek jika sudah login, arahkan ke index.php
if (isset($_SESSION['user_id'])) {
    header("Location: index.php"); 
    exit();
}

// Proses login jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil data pengguna berdasarkan username
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);  // Mengambil data sebagai array asosiatif

    // Periksa jika pengguna ditemukan dan password valid (plaintext comparison)
    if ($user && $password == $user['password']) {  // Dibandingkan langsung tanpa hashing
        // Jika login berhasil, simpan session dan redirect ke index.php
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header("Location: index.php");  // Arahkan ke index.php setelah login berhasil
        exit();
    } else {
        // Jika login gagal, tampilkan pesan error
        $error = "Username atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Menggunakan link Bootstrap untuk styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet"> <!-- Menambahkan font Poppins -->
    <style>
        body {
            background-color: #f4f4f9; /* Latar belakang ringan untuk konsistensi */
            font-family: 'Poppins', sans-serif; /* Menggunakan font Poppins */
            height: 100vh; /* Membuat tinggi halaman 100% */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: 1px solid #e0e0e0;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #006f42;  /* Warna hijau yang konsisten dengan tema index.php */
        }
        .alert {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: 600;
            color: #333;
        }
        .btn-primary {
            background-color: #006f42;  /* Warna hijau untuk tombol */
            border: none;
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #004d30;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login</h2>

    <!-- Menampilkan pesan error jika login gagal -->
    <?php if (isset($error)): ?>
        <div class="alert alert-danger">
            <?= $error; ?>
        </div>
    <?php endif; ?>

    <!-- Form Login -->
    <form method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
</div>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
