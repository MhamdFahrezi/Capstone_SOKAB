<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- header.php -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prediksi Penyusutan Puskesmas</title>
    <!-- Tautkan Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome untuk ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="style.css" rel="stylesheet"> <!-- Tautkan custom CSS -->
</head>
<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../images/logo2.png" alt="Logo Puskesmas" class="logo-img">
                    <span class="ms-2">Puskesmas</span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="index.php"><i class="fas fa-home me-1"></i> Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="inventory.php"><i class="fas fa-boxes me-1"></i> Inventory</a></li>
                        <li class="nav-item"><a class="nav-link" href="prediksi.php"><i class="fas fa-chart-line me-1"></i> Prediksi Penyusutan</a></li>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <li class="nav-item"><a class="nav-link" href="manage_staff.php"><i class="fas fa-users-cog me-1"></i> Kelola Staff</a></li>
                        <?php endif; ?>
                        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
