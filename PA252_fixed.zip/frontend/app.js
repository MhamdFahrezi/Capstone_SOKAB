document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById('prediksiForm');

    if (form) {
        form.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(form);
            const data = {};

            formData.forEach((value, key) => {
                data[key] = isNaN(value) ? value : parseFloat(value);
            });

            try {
                const response = await fetch(
                    "https://fastapi-production-d8cb.up.railway.app/predict", 
                    {
                    method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify(data),
                }
            );

                if (!response.ok) {
                    throw new Error('Server error: ' + response.statusText);
                }

                const result = await response.json();
                const hasilDiv = document.getElementById('hasil');

                if (result.error) {
                    hasilDiv.className = "alert alert-danger mt-4";
                    hasilDiv.innerText = "Error: " + result.error;
                } else {
                    hasilDiv.className = "alert alert-success mt-4";
                    hasilDiv.innerHTML = `
                        <h4>Hasil Prediksi:</h4>
                        <p><strong>Penyusutan Semester 1:</strong> ${result.Prediksi_Penyusutan_Semester_1}</p>
                        <p><strong>Penyusutan Semester 2:</strong> ${result.Prediksi_Penyusutan_Semester_2}</p>
                    `;
                }
                hasilDiv.classList.remove('d-none');
            } catch (error) {
                alert("Gagal menghubungi FastAPI: " + error.message);
            }
        });
    }
});
