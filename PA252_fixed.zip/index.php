<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();  // Memulai session hanya jika belum aktif
}
include('frontend/header.php');
?>

<!-- Bagian Hero (Halaman Utama) -->
<div class="notification success">
    <div class="container">
        <!-- Hero Section -->
        <div class="hero-section text-center mb-5">
            <h1>Prediksi Penyusutan Puskesmas</h1>
            <p>Sistem manajemen inventori dan prediksi penyusutan barang untuk efisiensi Puskesmas</p>
        </div>

        <!-- Fitur-Fitur Utama -->
        <div class="feature-cards d-flex justify-content-around">
            <div class="feature-card card p-4 shadow-sm text-center">
                <i class="fas fa-clipboard-list fa-2x mb-3"></i>
                <h3>Manajemen Inventori</h3>
                <p>Kelola data barang puskesmas dengan mudah dan terstruktur</p>
            </div>
            <div class="feature-card card p-4 shadow-sm text-center">
                <i class="fas fa-chart-line fa-2x mb-3"></i>
                <h3>Prediksi Penyusutan</h3>
                <p>Prediksi nilai penyusutan barang berdasarkan data historis</p>
            </div>
            <div class="feature-card card p-4 shadow-sm text-center">
                <i class="fas fa-file-export fa-2x mb-3"></i>
                <h3>Laporan Otomatis</h3>
                <p>Generate laporan penyusutan barang secara otomatis</p>
            </div>
        </div>

        <!-- Info Section (Tentang Sistem) -->
        <div class="info-section mt-5 text-center">
            <h2 class="mb-4">Tentang Sistem Kami</h2>
            <p>
                Sistem ini dikembangkan untuk membantu Puskesmas dalam mengelola inventori barang
                dan memprediksi nilai penyusutan barang secara akurat berdasarkan data historis.
                Dengan sistem ini, pengelolaan aset Puskesmas menjadi lebih efisien dan terukur.
            </p>
        </div>

        <!-- Lokasi Puskesmas Sidomulyo -->
        <div class="location-section mt-5">
            <h2 class="text-center mb-4">Lokasi Puskesmas Sidomulyo</h2>
            <div class="map-container">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4010.460547381699!2d117.15880870439341!3d-0.5008718353766851!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2df67f77f0418ab3%3A0xa9d3fd377172d3e3!2sPuskesmas%20Sidomulyo!5e0!3m2!1sid!2sid!4v1746803581865!5m2!1sid!2sid" 
                    width="100%" 
                    height="450" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>

    </div>
</div>

<?php include('frontend/footer.php'); ?>
