<?php
include('config/database.php'); // Memasukkan koneksi database
require 'vendor/autoload.php'; // Memuat autoloader dari Composer untuk PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\IOFactory;

$filePath = $_GET['file']; // Mengambil path file yang di-upload

// Fungsi untuk membaca file CSV
function readCSV($filePath) {
    $data = [];
    if (($handle = fopen($filePath, "r")) !== FALSE) {
        $header = fgetcsv($handle); // Membaca header CSV
        while (($row = fgetcsv($handle)) !== FALSE) {
            $data[] = array_combine($header, $row); // Menggabungkan header dengan data
        }
        fclose($handle);
    }
    return $data;
}

// Fungsi untuk membaca file Excel menggunakan PhpSpreadsheet
function readExcel($filePath) {
    $spreadsheet = IOFactory::load($filePath); // Membaca file Excel
    $sheet = $spreadsheet->getActiveSheet();  // Mendapatkan sheet aktif
    $data = [];
    
    foreach ($sheet->getRowIterator() as $row) {
        $rowData = [];
        foreach ($row->getCellIterator() as $cell) {
            $rowData[] = $cell->getValue(); // Mengambil data dari setiap sel
        }
        $data[] = $rowData;
    }
    
    return $data;
}

// Membaca file berdasarkan ekstensi
$ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
if ($ext == 'csv') {
    $data = readCSV($filePath); // Jika CSV
} else {
    $data = readExcel($filePath); // Jika Excel
}

// Menghitung penyusutan dan menyimpan ke database
foreach ($data as $item) {
    // Asumsi bahwa $item memiliki kolom: nama_barang, kategori, harga, tahun_perolehan
    $tahun_perolehan = $item[0]; // Sesuaikan dengan kolom yang ada di file
    $harga = $item[1]; // Sesuaikan dengan kolom yang ada di file
    $depreciation = $harga * 0.1; // Penyusutan 10% per tahun (Contoh)
    
    // Menyimpan data inventaris ke database
    $stmt = $pdo->prepare("INSERT INTO inventaris (nama_barang, kategori, harga, tahun_perolehan) VALUES (?, ?, ?, ?)");
    $stmt->execute([$item[2], $item[3], $harga, $tahun_perolehan]);  // Sesuaikan dengan urutan kolom
    
    // Mendapatkan ID inventaris yang baru dimasukkan
    $inventaris_id = $pdo->lastInsertId();
    
    // Menyimpan data penyusutan ke database
    $stmt = $pdo->prepare("INSERT INTO penyusutan (inventaris_id, tahun, nilai_penyusutan) VALUES (?, ?, ?)");
    $stmt->execute([$inventaris_id, $tahun_perolehan, $depreciation]);
}

echo "Data berhasil diproses dan disimpan.";
?>
