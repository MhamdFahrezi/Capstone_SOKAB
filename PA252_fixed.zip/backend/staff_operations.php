<?php
session_start();
?>
<header>
    <nav>
        <a href="home.php">Home</a>
        <a href="inventory.php">Inventaris</a>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <a href="manage_staff.php">Kelola Staff</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </nav>
</header>
