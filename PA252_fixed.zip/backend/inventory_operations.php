<?php
include('database.php');

header('Content-Type: application/json');

// Mendapatkan aksi dari parameter
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    // Aksi untuk mendapatkan data inventaris
    if ($action == 'get_inventory') {
        if (isset($_GET['id'])) {
            // Ambil data berdasarkan ID
            $stmt = $pdo->prepare("SELECT * FROM inventaris WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode($data);
        } else {
            // Ambil semua data
            $stmt = $pdo->query("SELECT * FROM inventaris");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($data);
        }
    }
    // Aksi untuk menyimpan data (create/update)
    elseif ($action == 'save_inventory') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        $data = [
            $input['nama_aset'],
            $input['masa_perolehan'],
            $input['nilai_perolehan'],
            $input['sisa_manfaat_tahun'] ?? 0,
            $input['sisa_manfaat_bulan'] ?? 0,
            $input['akumulasi_penyusutan_awal'] ?? 0,
            $input['penyusutan_semester1'] ?? 0,
            $input['penyusutan_semester2'] ?? 0,
            $input['akumulasi_penyusutan_akhir'] ?? 0,
            $input['nilai_buku'] ?? 0,
            $input['usia_aset'] ?? '',
            $input['terhitung'] ?? '',
            $input['hasil_akhir_penyusutan'] ?? '',
            $input['ada_penyusutan_s1'] ?? 0,
            $input['ada_penyusutan_s2'] ?? 0,
            $input['usia_aset_mapped'] ?? 0,
            $input['semester_depreciation_change_mapped'] ?? 0
        ];

        if (!empty($input['id'])) {
            // Update data
            $data[] = $input['id'];
            $stmt = $pdo->prepare("UPDATE inventaris SET 
                nama_aset = ?, masa_perolehan = ?, nilai_perolehan = ?,
                sisa_manfaat_tahun = ?, sisa_manfaat_bulan = ?,
                akumulasi_penyusutan_awal = ?, penyusutan_semester1 = ?,
                penyusutan_semester2 = ?, akumulasi_penyusutan_akhir = ?,
                nilai_buku = ?, usia_aset = ?, terhitung = ?,
                hasil_akhir_penyusutan = ?, ada_penyusutan_s1 = ?,
                ada_penyusutan_s2 = ?, usia_aset_mapped = ?,
                semester_depreciation_change_mapped = ?
                WHERE id = ?");
            $stmt->execute($data);
            echo json_encode(['status' => 'success', 'message' => 'Data berhasil diperbarui']);
        } else {
            // Insert data baru
            $stmt = $pdo->prepare("INSERT INTO inventaris (
                nama_aset, masa_perolehan, nilai_perolehan,
                sisa_manfaat_tahun, sisa_manfaat_bulan,
                akumulasi_penyusutan_awal, penyusutan_semester1,
                penyusutan_semester2, akumulasi_penyusutan_akhir,
                nilai_buku, usia_aset, terhitung,
                hasil_akhir_penyusutan, ada_penyusutan_s1,
                ada_penyusutan_s2, usia_aset_mapped,
                semester_depreciation_change_mapped
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute($data);
            echo json_encode(['status' => 'success', 'message' => 'Data berhasil ditambahkan', 'id' => $pdo->lastInsertId()]);
        }
    }
    // Aksi untuk menghapus data
    elseif ($action == 'delete_inventory') {
        $id = $_GET['id'] ?? $_POST['id'] ?? null;
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM inventaris WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['status' => 'success', 'message' => 'Data berhasil dihapus']);
        } else {
            throw new Exception("ID tidak valid");
        }
    } else {
        throw new Exception("Aksi tidak valid");
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>